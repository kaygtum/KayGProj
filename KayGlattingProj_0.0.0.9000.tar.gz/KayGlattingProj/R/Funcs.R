library(devtools)
library(testthat)
lyrics=function(...){
  UseMethod("lyrics")
}
lyrics.character=function(Name,...){
  List=read.csv("rhymes1.csv",header=T,sep=",")
  TitleN=-1
  for (k in 1:length(List[[1]])) {
    if (substr(List[[1]][k],1,5)==substr(Name,1,5)){
      TitleN=k
      break
    }

  }
  if (TitleN==-1){
    return(NULL)
  }
  print(strsplit(toString(List[[2]][[TitleN]],width=NULL),";"))
  return(strsplit(toString(List[[2]][[TitleN]],width=NULL),";"))
}
lyrics.double=function(num,...){
  List=read.csv("rhymes1.csv",header=T,sep=",")
  if (num>length(List[[1]])){
    return(NULL)
  }
  print(strsplit(toString(List[[2]][[num]],width=NULL),";"))
  return(strsplit(toString(List[[2]][[num]],width=NULL),";"))
}
sing=function(...){
  UseMethod("sing")
}
sing.character=function(Name,...){
  List=read.csv("rhymes1.csv",header=T,sep=",")
  TitleN=-1
  for (k in 1:length(List[[1]])) {
    if (substr(List[[1]][k],1,5)==substr(Name,1,5)){
      TitleN=k
      break
    }

  }
  if (TitleN==-1){
    stop()
  }


  lyrics1=strsplit(toString(List[[2]][[TitleN]],width=NULL),";")
  lyrics=Reduce(c,sapply(lyrics1, strsplit, split=" "))
  for(k in lyrics){
    print(k)
    Sys.sleep(0.1)
  }
}
sing.double=function(num...){
  List=read.csv("rhymes1.csv",header=T,sep=",")
  if (num>length(List[[1]])){
    stop()
  }


  lyrics1=strsplit(toString(List[[2]][[num]],width=NULL),";")
  lyrics=Reduce(c,sapply(lyrics1, strsplit, split=" "))
  for(k in lyrics){
    print(k)
    Sys.sleep(0.25)
  }
}
testfun=function(){
test_that(
  "Checking lyrics",
  {
    expect_false(isTRUE(all.equal(lyrics(1),1)))
    expect_false(isTRUE(all.equal(lyrics(2),1)))
    expect_false(isTRUE(all.equal(lyrics(3),1)))
    }
  )
}

